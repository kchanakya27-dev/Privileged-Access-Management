# JIT PAM Portal - Project TODO

## Core Features
- [x] Database schema: access_requests, audit_logs, notifications tables
- [x] Backend: access request creation API with validation
- [x] Backend: admin approval/denial workflow with comments
- [x] Backend: automatic JIT access expiry based on duration
- [x] Backend: audit log event recording (submitted, approved, denied, expired)
- [x] Backend: risk scoring calculation (access level + duration)
- [x] Backend: user management API (promote/demote admins)
- [x] Backend: notification triggers (email + in-app)
- [ ] Backend: periodic task to check and expire access requests

## Frontend - User Dashboard
- [x] User dashboard layout with request history
- [x] Request status indicators (Pending, Approved, Denied, Expired, Active)
- [x] Access request form with all four fields (system, level, justification, duration)
- [x] Live status updates for user's own requests

## Frontend - Admin Dashboards
- [x] Admin approval dashboard listing pending requests
- [x] Approve/deny actions with optional comments field
- [x] Risk scoring display on each request
- [x] Audit log viewer (admin-only) with event lifecycle
- [x] User management panel with promote/demote functionality

## Frontend - Cyberpunk Design System
- [x] Global CSS variables: neon pink (#FF10F0), electric cyan (#00F0FF), deep black (#0A0E27)
- [x] Bold geometric sans-serif font with neon glow effects
- [x] HUD-style layout with thin technical lines and corner brackets
- [x] Minimalist design with high contrast
- [x] Responsive layout for desktop and tablet

## Frontend - Navigation & Auth
- [x] Navigation bar with role-based menu items
- [x] User profile dropdown with logout
- [x] Login/auth flow integration
- [x] Role-based route protection (admin vs user pages)

## Notifications & Automation
- [ ] Email notifications for request submission (to admins)
- [ ] Email notifications for request approval/denial (to user)
- [x] In-app notification system
- [ ] Periodic expiry check job (Heartbeat integration)
- [ ] Automatic status update to "Expired" when duration elapses

## Testing & Polish
- [x] Vitest unit tests for backend procedures
- [x] Vitest tests for risk scoring logic
- [ ] Vitest tests for audit log recording
- [ ] UI/UX polish and edge case handling
- [ ] Cross-browser testing
