import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import * as db from "./db";

/**
 * Admin-only procedure: checks if user is admin
 */
const adminProcedure = publicProcedure.use(({ ctx, next }) => {
  if (!ctx.user || ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

/**
 * Calculate risk score based on access level and duration
 * Risk factors: admin access (high), write access (medium), read access (low)
 * Duration multiplier: longer duration = higher risk
 */
function calculateRiskScore(accessLevel: string, durationMinutes: number): number {
  let baseScore = 0;
  
  if (accessLevel === "admin") baseScore = 80;
  else if (accessLevel === "write") baseScore = 50;
  else if (accessLevel === "read") baseScore = 20;
  
  // Duration multiplier: every 60 minutes adds 10 points
  const durationMultiplier = Math.ceil(durationMinutes / 60) * 10;
  
  return Math.min(baseScore + durationMultiplier, 100);
}

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  /**
   * Access request management procedures
   */
  accessRequest: router({
    /**
     * Create a new access request (user)
     */
    create: publicProcedure
      .input(
        z.object({
          targetSystem: z.string().min(1, "Target system is required"),
          accessLevel: z.enum(["read", "write", "admin"]),
          justification: z.string().min(10, "Justification must be at least 10 characters"),
          requestedDurationMinutes: z.number().int().min(1).max(10080), // Max 7 days
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!ctx.user) {
          throw new TRPCError({ code: "UNAUTHORIZED" });
        }

        const result = await db.createAccessRequest({
          userId: ctx.user.id,
          targetSystem: input.targetSystem,
          accessLevel: input.accessLevel,
          justification: input.justification,
          requestedDurationMinutes: input.requestedDurationMinutes,
        });

        // Get the created request ID
        const requestId = (result as any).insertId;

        // Record audit log
        await db.recordAuditLog({
          requestId,
          event: "submitted",
          actorId: ctx.user.id,
          details: `User requested ${input.accessLevel} access to ${input.targetSystem}`,
        });

        // Create notification for admins
        const admins = await db.getAllUsers();
        for (const admin of admins) {
          if (admin.role === "admin") {
            await db.createNotification({
              userId: admin.id,
              requestId,
              type: "request_submitted",
              title: "New Access Request",
              message: `${ctx.user.name} requested ${input.accessLevel} access to ${input.targetSystem}`,
            });
          }
        }

        return { id: requestId, success: true };
      }),

    /**
     * Get user's own requests or all requests (if admin)
     */
    list: publicProcedure.query(async ({ ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }

      if (ctx.user.role === "admin") {
        const requests = await db.getAccessRequests();
        return requests.map((req) => ({
          ...req,
          riskScore: calculateRiskScore(req.accessLevel, req.requestedDurationMinutes),
        }));
      }

      const requests = await db.getAccessRequests({ userId: ctx.user.id });
      return requests.map((req) => ({
        ...req,
        riskScore: calculateRiskScore(req.accessLevel, req.requestedDurationMinutes),
      }));
    }),

    /**
     * Get a single request by ID
     */
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        if (!ctx.user) {
          throw new TRPCError({ code: "UNAUTHORIZED" });
        }

        const request = await db.getAccessRequestById(input.id);
        if (!request) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }

        // Check authorization: user can only see their own, admins see all
        if (ctx.user.role !== "admin" && request.userId !== ctx.user.id) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        return {
          ...request,
          riskScore: calculateRiskScore(request.accessLevel, request.requestedDurationMinutes),
        };
      }),

    /**
     * Approve an access request (admin only)
     */
    approve: adminProcedure
      .input(
        z.object({
          requestId: z.number(),
          comments: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const request = await db.getAccessRequestById(input.requestId);
        if (!request) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }

        // Calculate expiry time
        const expiresAt = new Date(Date.now() + request.requestedDurationMinutes * 60 * 1000);

        // Update request
        await db.updateAccessRequest(input.requestId, {
          status: "Active",
          approvedBy: ctx.user!.id,
          approvalComments: input.comments,
          expiresAt,
        });

        // Record audit log
        await db.recordAuditLog({
          requestId: input.requestId,
          event: "approved",
          actorId: ctx.user!.id,
          details: `Approved by ${ctx.user!.name}. Comments: ${input.comments || "None"}`,
        });

        // Notify requesting user
        const requester = await db.getUserByOpenId(request.userId.toString());
        if (requester) {
          await db.createNotification({
            userId: request.userId,
            requestId: input.requestId,
            type: "request_approved",
            title: "Access Request Approved",
            message: `Your request for ${request.accessLevel} access to ${request.targetSystem} has been approved until ${expiresAt.toLocaleString()}`,
          });
        }

        return { success: true };
      }),

    /**
     * Deny an access request (admin only)
     */
    deny: adminProcedure
      .input(
        z.object({
          requestId: z.number(),
          comments: z.string().min(1, "Denial reason is required"),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const request = await db.getAccessRequestById(input.requestId);
        if (!request) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }

        // Update request
        await db.updateAccessRequest(input.requestId, {
          status: "Denied",
          approvedBy: ctx.user!.id,
          approvalComments: input.comments,
        });

        // Record audit log
        await db.recordAuditLog({
          requestId: input.requestId,
          event: "denied",
          actorId: ctx.user!.id,
          details: `Denied by ${ctx.user!.name}. Reason: ${input.comments}`,
        });

        // Notify requesting user
        await db.createNotification({
          userId: request.userId,
          requestId: input.requestId,
          type: "request_denied",
          title: "Access Request Denied",
          message: `Your request for ${request.accessLevel} access to ${request.targetSystem} has been denied. Reason: ${input.comments}`,
        });

        return { success: true };
      }),
  }),

  /**
   * Audit log procedures (admin only)
   */
  auditLog: router({
    list: adminProcedure.query(async () => {
      return await db.getAuditLogs();
    }),

    getByRequest: adminProcedure
      .input(z.object({ requestId: z.number() }))
      .query(async ({ input }) => {
        return await db.getAuditLogs(input.requestId);
      }),
  }),

  /**
   * Notification procedures
   */
  notification: router({
    list: publicProcedure.query(async ({ ctx }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }
      return await db.getNotifications(ctx.user.id);
    }),

    markAsRead: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.markNotificationAsRead(input.id);
        return { success: true };
      }),
  }),

  /**
   * User management procedures (admin only)
   */
  userManagement: router({
    listAll: adminProcedure.query(async () => {
      return await db.getAllUsers();
    }),

    promoteToAdmin: adminProcedure
      .input(z.object({ userId: z.number() }))
      .mutation(async ({ input }) => {
        const user = await db.getUserByOpenId(input.userId.toString());
        if (!user) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        await db.upsertUser({ ...user, role: "admin" });
        return { success: true };
      }),

    demoteToUser: adminProcedure
      .input(z.object({ userId: z.number() }))
      .mutation(async ({ input }) => {
        const user = await db.getUserByOpenId(input.userId.toString());
        if (!user) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        await db.upsertUser({ ...user, role: "user" });
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
