import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId: number = 1, role: "user" | "admin" = "user"): TrpcContext {
  const user: AuthenticatedUser = {
    id: userId,
    openId: `user-${userId}`,
    email: `user${userId}@example.com`,
    name: `Test User ${userId}`,
    loginMethod: "manus",
    role,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("Risk Scoring", () => {
  it("calculates risk score correctly for read access", () => {
    // Risk score = base (20) + duration multiplier (ceil(30/60)*10 = 10) = 30
    const score = 20 + Math.ceil(30 / 60) * 10;
    expect(score).toBe(30);
  });

  it("calculates risk score correctly for write access", () => {
    // Risk score = base (50) + duration multiplier (ceil(120/60)*10 = 20) = 70
    const score = 50 + Math.ceil(120 / 60) * 10;
    expect(score).toBe(70);
  });

  it("calculates risk score correctly for admin access", () => {
    // Risk score = base (80) + duration multiplier (ceil(480/60)*10 = 80) = 160, capped at 100
    const score = Math.min(80 + Math.ceil(480 / 60) * 10, 100);
    expect(score).toBe(100);
  });
});

describe("Access Request Validation", () => {
  it("rejects request with missing target system", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.accessRequest.create({
        targetSystem: "",
        accessLevel: "read",
        justification: "Valid justification with enough characters",
        requestedDurationMinutes: 60,
      });
      expect.fail("Should have thrown validation error");
    } catch (error: any) {
      expect(error.code).toBe("BAD_REQUEST");
    }
  });

  it("rejects request with short justification", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.accessRequest.create({
        targetSystem: "Test System",
        accessLevel: "read",
        justification: "Too short",
        requestedDurationMinutes: 60,
      });
      expect.fail("Should have thrown validation error");
    } catch (error: any) {
      expect(error.code).toBe("BAD_REQUEST");
    }
  });

  it("rejects request with duration exceeding max", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.accessRequest.create({
        targetSystem: "Test System",
        accessLevel: "read",
        justification: "Valid justification with enough characters",
        requestedDurationMinutes: 20000, // Exceeds 10080 max
      });
      expect.fail("Should have thrown validation error");
    } catch (error: any) {
      expect(error.code).toBe("BAD_REQUEST");
    }
  });
});

describe("Admin-Only Operations", () => {
  it("prevents non-admin from approving requests", async () => {
    const ctx = createAuthContext(1, "user");
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.accessRequest.approve({
        requestId: 1,
        comments: "Approved",
      });
      expect.fail("Should have thrown FORBIDDEN error");
    } catch (error: any) {
      expect(error.code).toBe("FORBIDDEN");
    }
  });

  it("allows admin to approve requests", async () => {
    const ctx = createAuthContext(1, "admin");
    const caller = appRouter.createCaller(ctx);

    // Note: This test would need a real database to fully work
    // For now, we're just testing the authorization check
    try {
      await caller.accessRequest.approve({
        requestId: 999, // Non-existent request
        comments: "Approved",
      });
    } catch (error: any) {
      // Should fail with NOT_FOUND, not FORBIDDEN
      expect(error.code).toBe("NOT_FOUND");
    }
  });
});
