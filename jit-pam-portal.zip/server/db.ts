import { eq } from "drizzle-orm";
import { and, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, accessRequests, auditLogs, notifications, AccessRequest, AuditLog, Notification } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get all users (admin only)
 */
export async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(users);
}

/**
 * Create a new access request
 */
export async function createAccessRequest(data: {
  userId: number;
  targetSystem: string;
  accessLevel: 'read' | 'write' | 'admin';
  justification: string;
  requestedDurationMinutes: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(accessRequests).values({
    userId: data.userId,
    targetSystem: data.targetSystem,
    accessLevel: data.accessLevel,
    justification: data.justification,
    requestedDurationMinutes: data.requestedDurationMinutes,
    status: 'Pending',
  });
  
  return result;
}

/**
 * Get access requests filtered by status and user
 */
export async function getAccessRequests(filters?: {
  userId?: number;
  status?: string;
}) {
  const db = await getDb();
  if (!db) return [];
  
  let conditions: any[] = [];
  
  if (filters?.userId) {
    conditions.push(eq(accessRequests.userId, filters.userId));
  }
  if (filters?.status) {
    conditions.push(eq(accessRequests.status, filters.status as any));
  }
  
  if (conditions.length === 0) {
    return await db.select().from(accessRequests);
  }
  
  return await db.select().from(accessRequests).where(and(...conditions));
}

/**
 * Get a single access request by ID
 */
export async function getAccessRequestById(id: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.select().from(accessRequests).where(eq(accessRequests.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

/**
 * Update access request status (approval/denial)
 */
export async function updateAccessRequest(id: number, data: {
  status: 'Approved' | 'Denied' | 'Expired' | 'Active';
  approvedBy?: number;
  approvalComments?: string;
  expiresAt?: Date;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(accessRequests)
    .set({
      status: data.status,
      approvedBy: data.approvedBy,
      approvalComments: data.approvalComments,
      expiresAt: data.expiresAt,
      updatedAt: new Date(),
    })
    .where(eq(accessRequests.id, id));
}

/**
 * Record an audit log event
 */
export async function recordAuditLog(data: {
  requestId: number;
  event: 'submitted' | 'approved' | 'denied' | 'expired';
  actorId: number;
  details?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(auditLogs).values({
    requestId: data.requestId,
    event: data.event,
    actorId: data.actorId,
    details: data.details,
  });
}

/**
 * Get audit logs for a request
 */
export async function getAuditLogs(requestId?: number) {
  const db = await getDb();
  if (!db) return [];
  
  if (!requestId) {
    return await db.select().from(auditLogs);
  }
  
  return await db.select().from(auditLogs).where(eq(auditLogs.requestId, requestId));
}

/**
 * Create a notification
 */
export async function createNotification(data: {
  userId: number;
  requestId?: number;
  type: 'request_submitted' | 'request_approved' | 'request_denied' | 'request_expired';
  title: string;
  message: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(notifications).values({
    userId: data.userId,
    requestId: data.requestId,
    type: data.type,
    title: data.title,
    message: data.message,
    isRead: false,
  });
}

/**
 * Get notifications for a user
 */
export async function getNotifications(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(notifications).where(eq(notifications.userId, userId));
}

/**
 * Mark notification as read
 */
export async function markNotificationAsRead(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(notifications)
    .set({ isRead: true })
    .where(eq(notifications.id, id));
}

/**
 * Get expired access requests that need status update
 */
export async function getExpiredAccessRequests() {
  const db = await getDb();
  if (!db) return [];
  
  const now = new Date();
  return await db.select().from(accessRequests)
    .where(
      and(
        eq(accessRequests.status, 'Active'),
        lte(accessRequests.expiresAt, now)
      )
    );
}
