CREATE TABLE `access_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`targetSystem` varchar(255) NOT NULL,
	`accessLevel` enum('read','write','admin') NOT NULL,
	`justification` text NOT NULL,
	`requestedDurationMinutes` int NOT NULL,
	`status` enum('Pending','Approved','Denied','Expired','Active') NOT NULL DEFAULT 'Pending',
	`approvedBy` int,
	`approvalComments` text,
	`expiresAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `access_requests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `audit_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`requestId` int NOT NULL,
	`event` enum('submitted','approved','denied','expired') NOT NULL,
	`actorId` int NOT NULL,
	`details` text,
	`timestamp` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`requestId` int,
	`type` enum('request_submitted','request_approved','request_denied','request_expired') NOT NULL,
	`title` varchar(255) NOT NULL,
	`message` text NOT NULL,
	`isRead` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
