import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";
import { boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Access Requests table: stores JIT access requests from users
 * Each request tracks the target system, access level, justification, and approval status
 */
export const accessRequests = mysqlTable("access_requests", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(), // User who made the request
  targetSystem: varchar("targetSystem", { length: 255 }).notNull(), // e.g., "Production Database", "Admin Console"
  accessLevel: mysqlEnum("accessLevel", ["read", "write", "admin"]).notNull(), // Requested privilege level
  justification: text("justification").notNull(), // Why they need access
  requestedDurationMinutes: int("requestedDurationMinutes").notNull(), // How long they need access (in minutes)
  status: mysqlEnum("status", ["Pending", "Approved", "Denied", "Expired", "Active"]).default("Pending").notNull(),
  approvedBy: int("approvedBy"), // Admin who approved (nullable if pending/denied)
  approvalComments: text("approvalComments"), // Optional comments from approver
  expiresAt: timestamp("expiresAt"), // When the access expires (set when approved)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AccessRequest = typeof accessRequests.$inferSelect;
export type InsertAccessRequest = typeof accessRequests.$inferInsert;

/**
 * Audit Log table: immutable record of all access request lifecycle events
 * Events: submitted, approved, denied, expired
 */
export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  requestId: int("requestId").notNull(), // Reference to access_requests
  event: mysqlEnum("event", ["submitted", "approved", "denied", "expired"]).notNull(),
  actorId: int("actorId").notNull(), // User who triggered the event (or system for expiry)
  details: text("details"), // JSON or text details about the event
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;

/**
 * Notifications table: stores in-app notifications for users
 * Tracks which notifications have been read
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(), // Recipient
  requestId: int("requestId"), // Related access request (nullable for general notifications)
  type: mysqlEnum("type", ["request_submitted", "request_approved", "request_denied", "request_expired"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  isRead: boolean("isRead").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;
