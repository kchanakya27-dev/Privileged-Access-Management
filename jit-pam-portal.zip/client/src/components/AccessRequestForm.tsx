import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { toast } from "sonner";

interface AccessRequestFormProps {
  onSuccess?: () => void;
}

export default function AccessRequestForm({ onSuccess }: AccessRequestFormProps) {
  const [targetSystem, setTargetSystem] = useState("");
  const [accessLevel, setAccessLevel] = useState<"read" | "write" | "admin">("read");
  const [justification, setJustification] = useState("");
  const [duration, setDuration] = useState("60");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const createMutation = trpc.accessRequest.create.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await createMutation.mutateAsync({
        targetSystem,
        accessLevel,
        justification,
        requestedDurationMinutes: parseInt(duration),
      });

      toast.success("Access request submitted successfully");
      setTargetSystem("");
      setAccessLevel("read");
      setJustification("");
      setDuration("60");
      onSuccess?.();
    } catch (error: any) {
      toast.error(error.message || "Failed to submit request");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">
          Target System / Resource
        </label>
        <Input
          value={targetSystem}
          onChange={(e) => setTargetSystem(e.target.value)}
          placeholder="e.g., Production Database, Admin Console"
          className="bg-input border-border text-foreground"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-foreground mb-2">
          Access Level
        </label>
        <Select value={accessLevel} onValueChange={(v) => setAccessLevel(v as any)}>
          <SelectTrigger className="bg-input border-border text-foreground">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-card border-border">
            <SelectItem value="read">Read Only</SelectItem>
            <SelectItem value="write">Read & Write</SelectItem>
            <SelectItem value="admin">Admin Access</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <label className="block text-sm font-medium text-foreground mb-2">
          Justification
        </label>
        <Textarea
          value={justification}
          onChange={(e) => setJustification(e.target.value)}
          placeholder="Explain why you need this access..."
          className="bg-input border-border text-foreground min-h-24"
          required
          minLength={10}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-foreground mb-2">
          Duration (minutes)
        </label>
        <Input
          type="number"
          value={duration}
          onChange={(e) => setDuration(e.target.value)}
          min="1"
          max="10080"
          className="bg-input border-border text-foreground"
          required
        />
        <p className="text-xs text-muted-foreground mt-1">Max 7 days (10080 minutes)</p>
      </div>

      <Button
        type="submit"
        disabled={isSubmitting || !targetSystem || !justification}
        className="w-full glow-button bg-accent hover:bg-accent/80 text-accent-foreground"
      >
        {isSubmitting ? "Submitting..." : "Submit Request"}
      </Button>
    </form>
  );
}

