import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2 } from "lucide-react";
import { useLocation } from "wouter";

/**
 * All content in this page are only for example, replace with your own feature implementation
 * When building pages, remember your instructions in Frontend Workflow, Frontend Best Practices, Design Guide and Common Pitfalls
 */
export default function Home() {
  // The useAuth hook provides authentication state.
  // To implement login/logout, call logout(), or start login from an event
  // handler: onClick={() => startLogin()} (imported from "@/const"). Never call
  // startLogin() during render (no href={startLogin()}) — it mints a one-time
  // nonce cookie and must run only at the moment of navigation.
  let { user, loading, error, isAuthenticated, logout } = useAuth();
  const [, navigate] = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-accent" />
      </div>
    );
  }

  if (isAuthenticated && user) {
    // Redirect authenticated users to their dashboard
    return (
      <div className="min-h-screen bg-background text-foreground">
        <nav className="border-b border-border bg-card/50 backdrop-blur">
          <div className="max-w-6xl mx-auto px-6 py-4 flex justify-between items-center">
            <h1 className="text-2xl font-bold neon-text">JIT PAM</h1>
            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground">{user.name}</span>
              {user.role === "admin" && (
                <span className="text-xs px-2 py-1 bg-purple-900 text-purple-200 rounded">ADMIN</span>
              )}
              <Button
                onClick={() => logout()}
                variant="outline"
                className="text-sm"
              >
                Logout
              </Button>
            </div>
          </div>
        </nav>

        <div className="max-w-6xl mx-auto px-6 py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* User Dashboard */}
            <Card
              className="bg-card border-border p-8 hud-frame cursor-pointer hover:shadow-lg transition-all"
              onClick={() => navigate("/dashboard")}
            >
              <h2 className="text-2xl font-bold neon-text mb-2">My Requests</h2>
              <p className="text-muted-foreground mb-4">View and manage your access requests</p>
              <Button className="w-full glow-button bg-accent hover:bg-accent/80 text-accent-foreground">
                Open Dashboard
              </Button>
            </Card>

            {/* Admin Panels */}
            {user.role === "admin" && (
              <>
                <Card
                  className="bg-card border-border p-8 hud-frame cursor-pointer hover:shadow-lg transition-all"
                  onClick={() => navigate("/admin/approval")}
                >
                  <h2 className="text-2xl font-bold neon-text mb-2">Approval Queue</h2>
                  <p className="text-muted-foreground mb-4">Review and approve pending requests</p>
                  <Button className="w-full glow-button bg-green-700 hover:bg-green-600 text-white">
                    View Queue
                  </Button>
                </Card>

                <Card
                  className="bg-card border-border p-8 hud-frame cursor-pointer hover:shadow-lg transition-all"
                  onClick={() => navigate("/admin/audit")}
                >
                  <h2 className="text-2xl font-bold neon-text mb-2">Audit Log</h2>
                  <p className="text-muted-foreground mb-4">View complete request lifecycle history</p>
                  <Button className="w-full glow-button bg-blue-700 hover:bg-blue-600 text-white">
                    View Logs
                  </Button>
                </Card>

                <Card
                  className="bg-card border-border p-8 hud-frame cursor-pointer hover:shadow-lg transition-all"
                  onClick={() => navigate("/admin/users")}
                >
                  <h2 className="text-2xl font-bold neon-text mb-2">User Management</h2>
                  <p className="text-muted-foreground mb-4">Manage user roles and permissions</p>
                  <Button className="w-full glow-button bg-purple-700 hover:bg-purple-600 text-white">
                    Manage Users
                  </Button>
                </Card>
              </>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Hero Section */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-20">
        <div className="text-center max-w-2xl">
          <h1 className="text-6xl font-bold neon-text mb-4">JIT PAM PORTAL</h1>
          <p className="text-xl text-muted-foreground mb-2">Just-In-Time Privileged Access Management</p>
          <p className="text-lg text-muted-foreground mb-8">
            Secure, auditable, time-bound access control for your critical systems
          </p>

          <Button
            onClick={() => startLogin()}
            className="glow-button bg-accent hover:bg-accent/80 text-accent-foreground text-lg px-8 py-6"
          >
            Sign In to Continue
          </Button>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-20 w-full max-w-5xl">
          <Card className="bg-card border-border p-6 hud-frame">
            <h3 className="text-lg font-bold neon-text mb-2">Request Access</h3>
            <p className="text-sm text-muted-foreground">
              Submit time-bound access requests with justification and automatic expiry
            </p>
          </Card>

          <Card className="bg-card border-border p-6 hud-frame">
            <h3 className="text-lg font-bold neon-text mb-2">Smart Approval</h3>
            <p className="text-sm text-muted-foreground">
              Risk-scored requests help admins prioritize and make informed decisions
            </p>
          </Card>

          <Card className="bg-card border-border p-6 hud-frame">
            <h3 className="text-lg font-bold neon-text mb-2">Full Audit Trail</h3>
            <p className="text-sm text-muted-foreground">
              Complete lifecycle tracking of every access request for compliance
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
