import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle, XCircle } from "lucide-react";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

const riskLevels: Record<number, { label: string; color: string }> = {
  0: { label: "Low", color: "bg-green-900 text-green-200" },
  1: { label: "Medium", color: "bg-yellow-900 text-yellow-200" },
  2: { label: "High", color: "bg-orange-900 text-orange-200" },
  3: { label: "Critical", color: "bg-red-900 text-red-200" },
};

function getRiskLevel(score: number): number {
  if (score < 30) return 0;
  if (score < 60) return 1;
  if (score < 80) return 2;
  return 3;
}

export default function AdminApprovalDashboard() {
  const { data: requests, isLoading, refetch } = trpc.accessRequest.list.useQuery();
  const [selectedRequest, setSelectedRequest] = useState<any>(null);
  const [action, setAction] = useState<"approve" | "deny" | null>(null);
  const [comments, setComments] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);

  const approveMutation = trpc.accessRequest.approve.useMutation();
  const denyMutation = trpc.accessRequest.deny.useMutation();

  const pendingRequests = requests?.filter((r) => r.status === "Pending") || [];

  const handleApprove = async () => {
    if (!selectedRequest) return;
    setIsProcessing(true);

    try {
      await approveMutation.mutateAsync({
        requestId: selectedRequest.id,
        comments,
      });
      toast.success("Request approved");
      setSelectedRequest(null);
      setAction(null);
      setComments("");
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Failed to approve");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDeny = async () => {
    if (!selectedRequest || !comments) {
      toast.error("Please provide a reason for denial");
      return;
    }
    setIsProcessing(true);

    try {
      await denyMutation.mutateAsync({
        requestId: selectedRequest.id,
        comments,
      });
      toast.success("Request denied");
      setSelectedRequest(null);
      setAction(null);
      setComments("");
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Failed to deny");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold neon-text mb-2">APPROVAL QUEUE</h1>
          <p className="text-muted-foreground">Review and approve access requests</p>
        </div>

        {/* Approval Dialog */}
        <Dialog open={!!selectedRequest} onOpenChange={() => setSelectedRequest(null)}>
          <DialogContent className="bg-card border-border max-w-2xl">
            <DialogHeader>
              <DialogTitle className="neon-text">
                {action === "approve" ? "Approve Request" : "Deny Request"}
              </DialogTitle>
            </DialogHeader>

            {selectedRequest && (
              <div className="space-y-4">
                <div className="p-4 bg-muted/20 border border-muted rounded">
                  <p className="text-sm text-muted-foreground">
                    <strong>Requester:</strong> {selectedRequest.userId}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    <strong>System:</strong> {selectedRequest.targetSystem}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    <strong>Access Level:</strong> {selectedRequest.accessLevel.toUpperCase()}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    <strong>Duration:</strong> {selectedRequest.requestedDurationMinutes} minutes
                  </p>
                  <p className="text-sm text-muted-foreground mt-2">
                    <strong>Justification:</strong> {selectedRequest.justification}
                  </p>
                </div>

                {action === "deny" && (
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Reason for Denial (required)
                    </label>
                    <Textarea
                      value={comments}
                      onChange={(e) => setComments(e.target.value)}
                      placeholder="Explain why this request is being denied..."
                      className="bg-input border-border text-foreground"
                      required
                    />
                  </div>
                )}

                {action === "approve" && (
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Comments (optional)
                    </label>
                    <Textarea
                      value={comments}
                      onChange={(e) => setComments(e.target.value)}
                      placeholder="Add any notes about this approval..."
                      className="bg-input border-border text-foreground"
                    />
                  </div>
                )}

                <div className="flex gap-2">
                  <Button
                    onClick={() => setSelectedRequest(null)}
                    variant="outline"
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={action === "approve" ? handleApprove : handleDeny}
                    disabled={isProcessing || (action === "deny" && !comments)}
                    className={`flex-1 glow-button ${
                      action === "approve"
                        ? "bg-green-700 hover:bg-green-600"
                        : "bg-red-700 hover:bg-red-600"
                    }`}
                  >
                    {isProcessing ? "Processing..." : action === "approve" ? "Approve" : "Deny"}
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Requests Queue */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-4">
            <h2 className="text-2xl font-bold neon-text-cyan">Pending Requests</h2>
            <Badge className="bg-accent text-accent-foreground">{pendingRequests.length}</Badge>
          </div>

          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-accent" />
            </div>
          ) : pendingRequests.length > 0 ? (
            pendingRequests.map((request) => {
              const riskLevel = getRiskLevel(request.riskScore || 0);
              const riskInfo = riskLevels[riskLevel];

              return (
                <Card key={request.id} className="bg-card border-border p-6 hud-frame">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-foreground">{request.targetSystem}</h3>
                      <p className="text-sm text-muted-foreground line-clamp-2">{request.justification}</p>
                    </div>
                    <div className="flex gap-2">
                      <Badge className={riskInfo.color}>Risk: {riskInfo.label}</Badge>
                      <Badge className="bg-blue-900 text-blue-200">Score: {request.riskScore}</Badge>
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-4 text-sm mb-4">
                    <div>
                      <p className="text-muted-foreground">User ID</p>
                      <p className="font-semibold text-foreground">{request.userId}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Access Level</p>
                      <p className="font-semibold text-foreground uppercase">{request.accessLevel}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Duration</p>
                      <p className="font-semibold text-foreground">{request.requestedDurationMinutes} min</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Submitted</p>
                      <p className="font-semibold text-foreground">
                        {new Date(request.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      onClick={() => {
                        setSelectedRequest(request);
                        setAction("approve");
                        setComments("");
                      }}
                      className="flex-1 glow-button bg-green-700 hover:bg-green-600 text-white"
                    >
                      <CheckCircle className="mr-2 h-4 w-4" />
                      Approve
                    </Button>
                    <Button
                      onClick={() => {
                        setSelectedRequest(request);
                        setAction("deny");
                        setComments("");
                      }}
                      className="flex-1 glow-button bg-red-700 hover:bg-red-600 text-white"
                    >
                      <XCircle className="mr-2 h-4 w-4" />
                      Deny
                    </Button>
                  </div>
                </Card>
              );
            })
          ) : (
            <Card className="bg-card border-border p-12 text-center hud-frame">
              <p className="text-muted-foreground">No pending requests</p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

