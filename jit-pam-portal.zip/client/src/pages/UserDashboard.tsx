import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Plus } from "lucide-react";
import { useState } from "react";
import AccessRequestForm from "@/components/AccessRequestForm";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const statusColors: Record<string, string> = {
  Pending: "bg-yellow-900 text-yellow-200",
  Approved: "bg-green-900 text-green-200",
  Active: "bg-blue-900 text-blue-200",
  Denied: "bg-red-900 text-red-200",
  Expired: "bg-gray-700 text-gray-200",
};

export default function UserDashboard() {
  const { user } = useAuth();
  const [showForm, setShowForm] = useState(false);
  const { data: requests, isLoading, refetch } = trpc.accessRequest.list.useQuery();

  if (!user) return null;

  return (
    <div className="min-h-screen bg-background text-foreground p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold neon-text mb-2">ACCESS PORTAL</h1>
            <p className="text-muted-foreground">Manage your privileged access requests</p>
          </div>
          <Button
            onClick={() => setShowForm(true)}
            className="glow-button bg-accent hover:bg-accent/80 text-accent-foreground"
          >
            <Plus className="mr-2 h-4 w-4" />
            New Request
          </Button>
        </div>

        {/* Request Form Dialog */}
        <Dialog open={showForm} onOpenChange={setShowForm}>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle className="neon-text">Request Access</DialogTitle>
            </DialogHeader>
            <AccessRequestForm
              onSuccess={() => {
                setShowForm(false);
                refetch();
              }}
            />
          </DialogContent>
        </Dialog>

        {/* Requests List */}
        <div className="space-y-4">
          <h2 className="text-2xl font-bold neon-text-cyan mb-4">Your Requests</h2>

          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-accent" />
            </div>
          ) : requests && requests.length > 0 ? (
            requests.map((request) => (
              <Card key={request.id} className="bg-card border-border p-6 hud-frame">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-bold text-foreground">{request.targetSystem}</h3>
                    <p className="text-sm text-muted-foreground">{request.justification}</p>
                  </div>
                  <Badge className={statusColors[request.status]}>
                    {request.status}
                  </Badge>
                </div>

                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Access Level</p>
                    <p className="font-semibold text-foreground uppercase">{request.accessLevel}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Duration</p>
                    <p className="font-semibold text-foreground">{request.requestedDurationMinutes} min</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Requested</p>
                    <p className="font-semibold text-foreground">
                      {new Date(request.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                {request.expiresAt && (
                  <div className="mt-4 p-3 bg-muted/20 border border-muted rounded">
                    <p className="text-sm text-muted-foreground">
                      Expires: {new Date(request.expiresAt).toLocaleString()}
                    </p>
                  </div>
                )}

                {request.approvalComments && (
                  <div className="mt-4 p-3 bg-muted/20 border border-muted rounded">
                    <p className="text-sm text-muted-foreground">
                      <strong>Comments:</strong> {request.approvalComments}
                    </p>
                  </div>
                )}
              </Card>
            ))
          ) : (
            <Card className="bg-card border-border p-12 text-center hud-frame">
              <p className="text-muted-foreground mb-4">No access requests yet</p>
              <Button
                onClick={() => setShowForm(true)}
                className="glow-button bg-accent hover:bg-accent/80 text-accent-foreground"
              >
                Create Your First Request
              </Button>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

