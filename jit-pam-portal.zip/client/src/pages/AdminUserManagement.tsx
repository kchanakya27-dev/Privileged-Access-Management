import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Shield, ShieldOff } from "lucide-react";
import { toast } from "sonner";

export default function AdminUserManagement() {
  const { data: users, isLoading, refetch } = trpc.userManagement.listAll.useQuery();
  const promoteMutation = trpc.userManagement.promoteToAdmin.useMutation();
  const demoteMutation = trpc.userManagement.demoteToUser.useMutation();

  const handlePromote = async (userId: number) => {
    try {
      await promoteMutation.mutateAsync({ userId });
      toast.success("User promoted to admin");
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Failed to promote user");
    }
  };

  const handleDemote = async (userId: number) => {
    try {
      await demoteMutation.mutateAsync({ userId });
      toast.success("User demoted to regular user");
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Failed to demote user");
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold neon-text mb-2">USER MANAGEMENT</h1>
          <p className="text-muted-foreground">Manage user roles and permissions</p>
        </div>

        <div className="space-y-3">
          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-accent" />
            </div>
          ) : users && users.length > 0 ? (
            users.map((user: any) => (
              <Card key={user.id} className="bg-card border-border p-6 hud-frame">
                <div className="flex justify-between items-center">
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-foreground">{user.name}</h3>
                    <p className="text-sm text-muted-foreground">{user.email}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Joined: {new Date(user.createdAt).toLocaleDateString()}
                    </p>
                  </div>

                  <div className="flex items-center gap-4">
                    <Badge
                      className={
                        user.role === "admin"
                          ? "bg-purple-900 text-purple-200"
                          : "bg-gray-700 text-gray-200"
                      }
                    >
                      {user.role.toUpperCase()}
                    </Badge>

                    {user.role === "admin" ? (
                      <Button
                        onClick={() => handleDemote(user.id)}
                        variant="outline"
                        className="glow-button"
                      >
                        <ShieldOff className="mr-2 h-4 w-4" />
                        Demote
                      </Button>
                    ) : (
                      <Button
                        onClick={() => handlePromote(user.id)}
                        className="glow-button bg-purple-700 hover:bg-purple-600 text-white"
                      >
                        <Shield className="mr-2 h-4 w-4" />
                        Promote
                      </Button>
                    )}
                  </div>
                </div>
              </Card>
            ))
          ) : (
            <Card className="bg-card border-border p-12 text-center hud-frame">
              <p className="text-muted-foreground">No users found</p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
