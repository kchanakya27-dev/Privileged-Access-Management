import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2 } from "lucide-react";

const eventColors: Record<string, string> = {
  submitted: "bg-blue-900 text-blue-200",
  approved: "bg-green-900 text-green-200",
  denied: "bg-red-900 text-red-200",
  expired: "bg-gray-700 text-gray-200",
};

export default function AdminAuditLog() {
  const { data: logs, isLoading } = trpc.auditLog.list.useQuery();

  return (
    <div className="min-h-screen bg-background text-foreground p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold neon-text mb-2">AUDIT LOG</h1>
          <p className="text-muted-foreground">Complete lifecycle history of all access requests</p>
        </div>

        <div className="space-y-3">
          {isLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-accent" />
            </div>
          ) : logs && logs.length > 0 ? (
            logs.map((log: any) => (
              <Card key={log.id} className="bg-card border-border p-4 hud-frame">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge className={eventColors[log.event]}>
                        {log.event.toUpperCase()}
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        Request #{log.requestId}
                      </span>
                    </div>
                    <p className="text-sm text-foreground">{log.details}</p>
                  </div>
                  <div className="text-right text-sm text-muted-foreground">
                    <p>{new Date(log.timestamp).toLocaleDateString()}</p>
                    <p>{new Date(log.timestamp).toLocaleTimeString()}</p>
                  </div>
                </div>
              </Card>
            ))
          ) : (
            <Card className="bg-card border-border p-12 text-center hud-frame">
              <p className="text-muted-foreground">No audit log entries</p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
