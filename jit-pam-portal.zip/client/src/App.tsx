import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { useAuth } from "./_core/hooks/useAuth";
import UserDashboard from "./pages/UserDashboard";
import AdminApprovalDashboard from "./pages/AdminApprovalDashboard";
import AdminAuditLog from "./pages/AdminAuditLog";
import AdminUserManagement from "./pages/AdminUserManagement";
import Home from "./pages/Home";

function ProtectedRoute({ component: Component, adminOnly = false }: { component: any; adminOnly?: boolean }) {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="min-h-screen bg-background flex items-center justify-center text-foreground">Loading...</div>;
  }

  if (!user) {
    return <Home />;
  }

  if (adminOnly && user.role !== "admin") {
    return <NotFound />;
  }

  return <Component />;
}

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/dashboard"} component={() => <ProtectedRoute component={UserDashboard} />} />
      <Route path={"/admin/approval"} component={() => <ProtectedRoute component={AdminApprovalDashboard} adminOnly />} />
      <Route path={"/admin/audit"} component={() => <ProtectedRoute component={AdminAuditLog} adminOnly />} />
      <Route path={"/admin/users"} component={() => <ProtectedRoute component={AdminUserManagement} adminOnly />} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
